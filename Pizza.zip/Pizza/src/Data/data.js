export const foodData = [
  {
    id: 1,
    image:
      "https://cdn.loveandlemons.com/wp-content/uploads/2022/07/grilled-tomatoes-1-700x1024.jpg",
    title: "Grilled Tomatoes at Home",
    body: "lorem",
  },
  {
    id: 2,
    image:
      "https://www.forkinthekitchen.com/wp-content/uploads/2018/08/peach.salsa-8945-6.jpg",
    title: "Snacks for Travel",
    body: "lorem",
  },
  {
    id: 3,
    image:
      "https://i.pinimg.com/564x/a9/46/f9/a946f9a360806c10bf6a9d54c0e5ed28.jpg",
    title: "Post-workout Recipes",
    body: "lorem",
  },
  {
    id: 4,
    image:
      "https://www.recipetineats.com/wp-content/uploads/2019/07/Grilled-Corn_0.jpg",
    title: "How To Grill Corn",
    body: "lorem",
  },
  {
    id: 5,
    image:
      "https://pinchofyum.com/wp-content/uploads/Vegan-Crunchwraps-with-Cashew-Queso-960x1440.jpg",
    title: "Crunchwarp Supreme",
    body: "lorem",
  },
  {
    id: 6,
    image:
      "https://www.cookingclassy.com/wp-content/uploads/2020/09/broccoli-cheese-soup-3-1024x1536.jpg",
    title: "Broccoli Cheese Soup",
    body: "lorem",
  },
];
